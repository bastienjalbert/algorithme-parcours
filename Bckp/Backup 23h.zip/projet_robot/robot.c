
#include <stdio.h>
#include <stdlib.h>

#include "robot.h"


// comparer deux coordonnées
// @return : 0 si elles sont égales, puis
//           TODO : les autres retours ?
int Compare(Coordonnee c1, Coordonnee c2) {

    if(c1.num_col == c2.num_col &&
       c1.num_ligne == c2.num_ligne) {
        return 0;
    }

    return 1;
}

/**
 * Vérifie si une étape est déjà présente dans une liste d'étape passée en argument
 * @return : true l'étape est présente, false sinon
 */
bool Verif_Etape_Appartient_liste(Liste_dynamique_generique * li, Etape etape_courante) {

  // on commence par récupérer la tête de la liste
  Element_liste_dynamique_generique tmp;
  tete_liste_dynamique(cases_marques, &tmp);

  // on itére dans toute la liste pour essayer de trouver etape_courante
  for(int i = 0 ; i < li->iTaille ; i++) {
    // on vérifie si les coordonnées de la case de l'étape courante
    // existe au sein de l'élèment n°i de la liste
    if(Compare(etape_courante.tdDonnee.coord, tmp.tdDonnee.coord)) {
        return true;
    }
    // on assigne l'élèment d'après à tmp puis on réitére
    tmp = tmp.ElementSuivant;
  }

  return false;
}

/**
 * Permet de déterminer si la case est visitable "physiquement", si elle l'est alors :
 * - La case n'est pas hors de la map
 * - La case est bien un caractère espace
 * @return true si elle est visitable, false sinon
 */
bool evaluation(Coordonnee case_courante,Problem *problem) {

  // coordonnées de la case (<=> étape) courante
  int cur_col = etape_courante.coord.num_col;
  int cur_lin = etape_courante.coord.num_ligne;

  if(cur_col < 0 || cur_col > problem->nb_colonne // si la case dépasse des bords
    || cur_lin < 0 || cur_lin > problem->nb_ligne // de la carte .... ou
    || problem->carte[cur_lin][cur_col] != ' ' // si la case ne contient pas un espace
  ) {
    return false;
  }

  return true;

}

/**
 * Récupére la liste des toutes les cases voisines visitables
 *
 */
int etat_suivants(Etape etape_courante, Liste_dynamique_generique etapes_suivantes, int *nb_elem ) {

  // coordonnées de la case (<=> étape) courante
  int cur_col = etape_courante.coord.num_col;
  int cur_lin = etape_courante.coord.num_ligne;

  // case du dessus
  if(evaluation(etape_courante->coord, )
     && Verif_Etape_Appartient_liste(cases_marques, etape_courante) // si on n'est pas déjà passé par cette case
   ) {uccesseursPossibles[nbPossible] = tmp;
     }

}


void getSuccesseurs(Coordonnee * etape_courante, Liste_dynamique_generique * cases_marques, Problem * probleme, Coordonnee * successeursPossibles) {

    // case courante
    int cur_col = etape_courante->num_col;
    int cur_lin = etape_courante->num_ligne;

    // Coordonn�e temporaire pour ajout dans tableau
    Coordonnee tmp = {0, 0};

    //
    int nbPossible = 0;



    // case du dessus
    if(cur_lin - 1 >= 0 // on v�rifie si on monte pas trop haut dans la map
       && estPresenteDansLaListe(cases_marques, cur_col, cur_lin - 1) // si on est pas d�j� pass� dans cette case
       && probleme->carte[cur_col][cur_lin - 1] == ' ' // on v�firi si on peut passer
       ) {

        tmp.num_ligne = cur_lin - 1;
        tmp.num_col = cur_col;
        successeursPossibles[nbPossible] = tmp;
       } else {
         tmp.num_ligne = -22;
         tmp.num_col = -22;
         successeursPossibles[nbPossible] = tmp;
       }

       nbPossible++;

    // case du dessous
    if(cur_lin + 1 <= probleme->nb_ligne // on v�rifie si on monte pas trop haut dans la map
       && estPresenteDansLaListe(cases_marques, cur_col, cur_lin + 1)
       && probleme->carte[cur_col][cur_lin + 1] == ' ' // on v�firi si on peut passer
       ) {

        tmp.num_ligne = cur_lin + 1;
        tmp.num_col = cur_col;
        successeursPossibles[nbPossible] = tmp;
       }  else {
         tmp.num_ligne = -22;
         tmp.num_col = -22;
         successeursPossibles[nbPossible] = tmp;
       }

       nbPossible++;

    // case de gauche
    if(cur_col - 1 >= 0 // on v�rifie si on monte pas trop haut dans la map
       && estPresenteDansLaListe(cases_marques, cur_col, cur_lin - 1)
       && probleme->carte[cur_col - 1][cur_lin] == ' ' // on v�firi si on peut passer
       ) {

        tmp.num_ligne = cur_lin;
        tmp.num_col = cur_col -1;
        successeursPossibles[nbPossible] = tmp;
       }  else {
         tmp.num_ligne = -22;
         tmp.num_col = -22;
         successeursPossibles[nbPossible] = tmp;
       }

       nbPossible++;

    // case de droite
    if(cur_col + 1 <= probleme->nb_colonne // on v�rifie si on monte pas trop haut dans la map
       && estPresenteDansLaListe(cases_marques, cur_col, cur_lin + 1)
       && probleme->carte[cur_col + 1][cur_lin] == ' ' // on v�firi si on peut passer
       ) {

        tmp.num_ligne = cur_lin;
        tmp.num_col = cur_col + 1;
        successeursPossibles[nbPossible] = tmp;
       }  else {
         tmp.num_ligne = -22;
         tmp.num_col = -22;
         successeursPossibles[nbPossible] = tmp;
       }



}

void parcours_largeur(Problem *pb) {

    /// la map
    char ** map = pb->carte;
//
    Coordonnee arrive = pb->arrive;
//
    Coordonnee depart = pb->depart;

    Coordonnee caseCourante;

    Coordonnee * successeurPossible;

    // cas�es trait�es
    Liste_dynamique_generique * cases_traitement = malloc(1024);

    // cas�es marqu�es
    Liste_dynamique_generique * cases_marques = malloc(1024);


    Ajouter_elem_tete_liste_dynamique_generique(cases_traitement, &depart, sizeof(depart));
    Ajouter_elem_tete_liste_dynamique_generique(cases_marques, &depart, sizeof(depart));


    if(!Creer_liste_dynamique_generique(cases_traitement) ||
            !Creer_liste_dynamique_generique(cases_marques)) {
        printf("Probleme a d�finir\n");
        exit;
    }

    do {
        // on r�cup�re la t�te de la file
        Enlever_elem_tete_liste_dynamique_generique(cases_marques, &caseCourante, sizeof(Coordonnee));

        getSuccesseurs(&caseCourante, cases_marques, pb, successeurPossible);
        // on ajoute les successeurs possibles � la liste
        for(int i = 0 ; i < 4 ; i++) {
            if(successeurPossible[i].num_ligne == -22)
                continue;
             Ajouter_elem_fin_liste_dynamique_generique(cases_traitement, successeurPossible[i], sizeof(successeurPossible[i]));
        }







    } while(Compare(caseCourante, depart) != 0);







}

void lire_fichier(FILE *f, Problem *p) {
    char c;
    fscanf(f,"%s\n",p->nom);
    lire_coordonnee(f,&p->depart);
    lire_coordonnee(f,&p->arrive);
    fscanf(f,"%i\n",&p->nb_ligne);
    fscanf(f,"%i\n",&p->nb_colonne);
    p->carte = (char **) malloc(sizeof(char *)*p->nb_ligne);
    if(p->carte==NULL) {
        printf("\nallocation impossible, pas assez de m�moire\n");
        exit (1);
    } else {
        for (int i = 0; i < p->nb_ligne; i++) {
            p->carte[i] = (char*)malloc(sizeof(char)*p->nb_colonne);
            if (p->carte[i]==NULL) {
                printf("\nallocation impossible, pas assez de m�moire\n");
                exit (1);
                }
            }
        }
    for (int i = 0; i < p->nb_ligne; i++) {
        for(int j=0; j< p->nb_colonne; j++) {
            fscanf(f,"%c",&p->carte[i][j]);
            }
        fscanf(f,"%c",&c);  // enl�ve le \n
        }
    }
void Affiche_matrice(Problem *p) {
    printf("nom du labyrinthe : %s\n", p->nom);
    printf("position de depart : %i;%i\n",p->depart.num_ligne,p->depart.num_col);
    printf("position de arrivee : %i;%i\n",p->arrive.num_ligne,p->arrive.num_col);
    printf("nb_ligne : %i; nb_colonne : %i\n", p->nb_ligne, p->nb_colonne);
    for (int i = 0; i < p->nb_ligne; i++) {
        printf("|");
        for (int j = 0; j < p->nb_colonne; j++) {
            if( p->arrive.num_ligne==i&&p->arrive.num_col==j){
                putchar('A');
            }else if( p->depart.num_ligne==i&&p->depart.num_col==j){
                putchar('D');
            }else{
                printf("%c",p->carte[i][j]);
            }
        }
         printf("|");
        }
    }

void lire_coordonnee(FILE *f, Coordonnee *c) {
    fscanf(f,"%i\t%i\n",&c->num_ligne,&c->num_col);
    }

void libere_matrice(Problem *p){
    for (int i = 0; i < p->nb_ligne; i++) {
       free(p->carte[i]);
        }
    free(p->carte);
    }
